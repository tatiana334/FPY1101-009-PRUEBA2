#valores 
medicamento = 60000
despacho = 8000

#entrado
edad = int(input("Ingresa tu edad: "))
tramo = input("Ingresa tu tramo (A, B, C o D):").upper()

#descuento medicamentos
if edad > 60:
    descuento_ = 0
elif edad <=30:
    if tramo == "A" or tramo == "B":
        descuento_ = 0.18
    else:
        descuento_ = 0.12
else:
    if tramo == "A" or tramo == "B":
        descuento_ = 0.12
    else: 
        descuento_ = 0.08

#calculo medicamentos
valor_medicamentos = medicamento - (medicamento * descuento_)

#descuento despacho
despacho_des = 0
if tramo== "A" or tramo == "B":
    despacho_des = 0.10
if edad >= 55:
    despacho_des += 0.05 
else:
    if edad >= 61:
        despacho_des = 0

#calculo des
valor_des = despacho - (despacho * despacho_des)

#resultado
print("El valor del medicamento es:", int(valor_medicamentos))
print("el valordel despacho es:", int(valor_des))