from random import randint

limite_inf = int(input("Ingrese el limite inferior:"))
limite_sup = int(input("Ingrese el limite superior:"))

if limite_inf >= limite_sup:
    print("Error: el limite inferior debe ser menor que el limite superior")
else:
    print("Rango correcto")

    numero = randint(limite_inf, limite_sup)

    if numero%2 == 0:
        if numero +1 <= limite_sup:
            numero_final = numero + 1
        else:
            numero_final = numero - 1
    else:
        numero_final = numero 

    intentos = 1
    adivino = False

    intento1 = 0
    intento2 = 0

    while intentos <= 3 and adivino == False:
        intento = int(input(f"intento {intentos}: "))

        if intento == numero_final:
            print("Felicidades, pudiste adivinar.")
            adivino = True
        else:
            if intento <numero_final:
                print("El número es mayor...")
            else:
                print("El número es menor")
            
        if intentos == 1:
            intento1 = intento 
        elif intentos == 2:
            intento2 = intento

            distancia1 = abs(numero_final - intento1)
            distancia2 = abs(numero_final - intento2)

            print("Te dare una pista:")

            if distancia1 < distancia2:
                print("el número está mas cerca de ", intento1, "que de", intento2)
            elif distancia2 < distancia1:
                print("El número esta mas cerca de", intento2, "que de", intento1)
            else:
                print("Ambos intentos estuvieron igual de cerca")

        intento += 1
    if adivino == False:
        print("perdiste. :(")
        print("El número era:", numero_final)
        


